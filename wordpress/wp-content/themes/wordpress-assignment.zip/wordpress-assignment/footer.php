<?php
/**
 * The template for displaying the footer
 *
 * Contains the closing of the #content div and all content after.
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package CMSassignment
 */

?>

	</div><!-- #content -->

	<footer id="colophon" class="site-footer">
		<div class="site-info">
			<p>
				This website was produced by students in the Faculty of Arts & Design, University of Canberra. The text and images reproduced on this site were generously provided by [Canberra House]Make text in square brackets a link to this page: http://www.canberrahouse.com.au.
			</p>
			
		</div><!-- .site-info -->
	</footer><!-- #colophon -->
</div><!-- #page -->

<?php wp_footer(); ?>

</body>
</html>
